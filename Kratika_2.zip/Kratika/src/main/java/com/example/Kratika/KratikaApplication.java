package com.example.Kratika;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@RestController
public class KratikaApplication {

	public static void main(String[] args) {
		SpringApplication.run(KratikaApplication.class, args);
	}

	@GetMapping("/hello")
	public String hello(){
		return Sting.format("Hello World !!")
	}
}
