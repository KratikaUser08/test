package com.example.Kratika;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KratikaApplicationTests {

	@Test
	void contextLoads() {
	}

}
